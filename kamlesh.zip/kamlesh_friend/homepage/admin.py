from django.contrib import admin

from .models import contactus, Regis_db

admin.site.register(contactus)
admin.site.register(Regis_db)

# Register your models here.
