from django.contrib import admin

from .models import emp_account

admin.site.register(emp_account)

# Register your models here.
