from django.apps import AppConfig


class PayrollAdminConfig(AppConfig):
    name = 'payroll_admin'
